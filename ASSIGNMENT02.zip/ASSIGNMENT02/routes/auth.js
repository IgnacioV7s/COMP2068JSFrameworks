var express = require('express');
var router = express.Router();

router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Login', stylesheet: 'login.css', script: 'login.js' });
});

router.get('/register', function(req, res, next) {
  res.render('register', { title: 'Register', stylesheet: 'register.css', script: 'register.js' });
});

module.exports = router;
