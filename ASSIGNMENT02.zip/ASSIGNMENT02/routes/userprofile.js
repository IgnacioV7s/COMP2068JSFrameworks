var express = require('express');
var router = express.Router();

// Middleware para verificar si el usuario está autenticado
function isAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {  // Si está autenticado, sigue adelante
    return next();
  }
  res.redirect('/login');  // Si no, redirige al login
}

router.get('/', isAuthenticated, function(req, res, next) {
  res.render('userprofile', { 
    title: 'User Profile', 
    stylesheet: 'userprofile.css', 
    script: 'userprofile.js', 
    user: req.user  // Pasa los datos del usuario a la vista
  });
});

module.exports = router;