var express = require('express');
var router = express.Router();

const Payment = require('../models/payment');

router.get('/general', async (req, res, next) => {
  let data = await Payment.find().sort({ paymentDate: 1 });
  res.render('payments/general', { title: 'Payments', stylesheet: 'payments.css', dataset: data });
});

router.get('/addpayment', (req, res, next) => {
  res.render('payments/addpayment', { title: 'Payments', stylesheet: 'addpayment.css' });
})

router.post('/add', async (req, res, next) => {
  try {
    // Verificamos si el usuario existe
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).send("User not found");
    }

    let newPayment = new Payment({
      userId,  // Asociamos el pago al usuario
      amountPaid: parseFloat(paymentAmount),
      lastPayment: new Date(paymentDate),
      status: new Date(paymentDate) <= new Date() ? 'On Time' : 'Late'
    });


    await newPayment.save();
    res.redirect('/payments/general');
  });

module.exports = router;
